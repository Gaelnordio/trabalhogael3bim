# Nordio's Care — Sistema do Posto de Saúde

Aplicação Flask para gerenciamento de pacientes e consultas, agora com persistência em banco SQLite, autenticação de usuários, dashboard e gamificação.

## Funcionalidades

- **Banco de dados:** Flask-SQLAlchemy com SQLite (`posto_saude.db`), tabelas `usuarios`, `pacientes` e `consultas`.
- **Autenticação:** cadastro, login, logout e proteção das páginas internas com Flask-Login.
- **Senhas seguras:** a senha nunca é armazenada em texto puro; o sistema usa `Werkzeug` para gerar e validar hash criptográfico.
- **Gestão:** cadastro/listagem/exclusão de pacientes, agendamento, confirmação, marcação como realizada, cancelamento e link de WhatsApp.
- **Dashboard:** cards de indicadores, gráfico de status dos atendimentos e atividade recente.
- **Gamificação:** pontos de experiência (XP), níveis e quatro conquistas desbloqueáveis na página **Conquistas**.

## Como executar

```bash
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python app.py
```

Acesse `http://127.0.0.1:5000`, crie sua conta e comece a usar. O banco é criado automaticamente na primeira execução.

## Pontuação

| Ação | XP |
|---|---:|
| Cadastrar paciente | 10 |
| Agendar consulta | 5 |
| Confirmar ou realizar consulta | 15 |

> Em produção, altere `SECRET_KEY` em `app.py` para uma variável de ambiente secreta e utilize um banco gerenciado.
