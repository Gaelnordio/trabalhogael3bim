from datetime import datetime
from urllib.parse import quote

from flask import Flask, flash, redirect, render_template, request, url_for
from flask_login import LoginManager, UserMixin, current_user, login_required, login_user, logout_user
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.config["SECRET_KEY"] = "troque-esta-chave-em-producao"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///posto_saude.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"
login_manager.login_message = "Entre na sua conta para continuar."
login_manager.login_message_category = "info"


class Usuario(UserMixin, db.Model):
    __tablename__ = "usuarios"
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False, index=True)
    senha_hash = db.Column(db.String(255), nullable=False)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def definir_senha(self, senha):
        self.senha_hash = generate_password_hash(senha)

    def verificar_senha(self, senha):
        return check_password_hash(self.senha_hash, senha)


class Paciente(db.Model):
    __tablename__ = "pacientes"
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(140), nullable=False)
    idade = db.Column(db.Integer, nullable=False)
    telefone = db.Column(db.String(40), nullable=False)
    endereco = db.Column(db.String(240), nullable=False)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    consultas = db.relationship("Consulta", backref="paciente", cascade="all, delete-orphan", lazy=True)


class Consulta(db.Model):
    __tablename__ = "consultas"
    id = db.Column(db.Integer, primary_key=True)
    paciente_id = db.Column(db.Integer, db.ForeignKey("pacientes.id"), nullable=False)
    data = db.Column(db.String(10), nullable=False)
    horario = db.Column(db.String(5), nullable=False)
    motivo = db.Column(db.String(240), nullable=False, default="Avaliação")
    status = db.Column(db.String(30), nullable=False, default="A confirmar")
    criado_em = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)


@login_manager.user_loader
def carregar_usuario(usuario_id):
    return db.session.get(Usuario, int(usuario_id))


@app.context_processor
def dados_globais():
    return {"ano_atual": datetime.now().year}


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        senha = request.form.get("senha", "")
        usuario = Usuario.query.filter_by(email=email).first()
        if usuario and usuario.verificar_senha(senha):
            login_user(usuario)
            flash("Bem-vindo ao painel do posto de saúde!", "success")
            return redirect(url_for("dashboard"))
        flash("E-mail ou senha inválidos.", "error")
    return render_template("login.html")


@app.route("/cadastro", methods=["GET", "POST"])
def cadastro():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        email = request.form.get("email", "").strip().lower()
        senha = request.form.get("senha", "")
        confirmacao = request.form.get("confirmacao", "")
        if len(nome) < 2 or "@" not in email or len(senha) < 6:
            flash("Preencha os dados corretamente. A senha deve ter pelo menos 6 caracteres.", "error")
        elif senha != confirmacao:
            flash("As senhas não coincidem.", "error")
        elif Usuario.query.filter_by(email=email).first():
            flash("Este e-mail já está cadastrado.", "error")
        else:
            usuario = Usuario(nome=nome, email=email)
            usuario.definir_senha(senha)
            db.session.add(usuario)
            db.session.commit()
            login_user(usuario)
            flash("Conta criada com sucesso.", "success")
            return redirect(url_for("dashboard"))
    return render_template("cadastro.html")


@app.route("/sair")
@login_required
def sair():
    logout_user()
    flash("Você saiu da sua conta.", "info")
    return redirect(url_for("login"))


@app.route("/")
@login_required
def index():
    return redirect(url_for("dashboard"))


@app.route("/dashboard")
@login_required
def dashboard():
    total_pacientes = Paciente.query.count()
    total_consultas = Consulta.query.count()
    confirmadas = Consulta.query.filter_by(status="Confirmada").count()
    realizadas = Consulta.query.filter_by(status="Realizada").count()
    pendentes = Consulta.query.filter_by(status="A confirmar").count()
    canceladas = Consulta.query.filter_by(status="Cancelada").count()
    recentes = Consulta.query.order_by(Consulta.id.desc()).limit(5).all()
    por_status = {"Confirmadas": confirmadas, "Realizadas": realizadas, "Pendentes": pendentes, "Canceladas": canceladas}
    max_status = max(por_status.values(), default=1) or 1
    return render_template("dashboard.html", total_pacientes=total_pacientes,
                           total_consultas=total_consultas, confirmadas=confirmadas,
                           realizadas=realizadas, pendentes=pendentes, canceladas=canceladas, recentes=recentes,
                           por_status=por_status, max_status=max_status)


@app.route("/pacientes")
@login_required
def pacientes_lista():
    return render_template("pacientes.html", pacientes=Paciente.query.order_by(Paciente.nome).all())


@app.route("/cadastrar_paciente", methods=["GET", "POST"])
@login_required
def cadastrar_paciente():
    if request.method == "POST":
        try:
            paciente = Paciente(nome=request.form["nome"].strip(), idade=int(request.form["idade"]),
                                telefone=request.form["telefone"].strip(), endereco=request.form["endereco"].strip())
            db.session.add(paciente)
            db.session.commit()
            flash("Paciente cadastrado e pontuação atualizada! +10 XP", "success")
            return redirect(url_for("pacientes_lista"))
        except (KeyError, ValueError):
            db.session.rollback()
            flash("Confira os campos do paciente.", "error")
    return render_template("cadastrar_paciente.html")


@app.route("/consultas")
@login_required
def consultas_lista():
    return render_template("consultas.html", consultas=Consulta.query.order_by(Consulta.data, Consulta.horario).all())


@app.route("/agendar", methods=["GET", "POST"])
@login_required
def agendar():
    pacientes = Paciente.query.order_by(Paciente.nome).all()
    if request.method == "POST":
        paciente = db.session.get(Paciente, request.form.get("id", type=int))
        if not paciente:
            flash("Selecione um paciente válido.", "error")
        else:
            consulta = Consulta(paciente_id=paciente.id, data=request.form["data"], horario=request.form["horario"],
                                motivo=request.form.get("motivo", "Avaliação").strip() or "Avaliação")
            db.session.add(consulta)
            db.session.commit()
            flash("Consulta agendada com sucesso! +5 XP", "success")
            return redirect(url_for("consultas_lista"))
    return render_template("agendar.html", pacientes=pacientes)


@app.route("/excluir_paciente/<int:id>")
@login_required
def excluir_paciente(id):
    paciente = db.session.get(Paciente, id)
    if paciente:
        db.session.delete(paciente)
        db.session.commit()
        flash("Paciente removido.", "info")
    return redirect(url_for("pacientes_lista"))


@app.route("/excluir_consulta/<int:id>")
@login_required
def excluir_consulta(id):
    consulta = db.session.get(Consulta, id)
    if consulta:
        db.session.delete(consulta)
        db.session.commit()
        flash("Consulta removida.", "info")
    return redirect(url_for("consultas_lista"))


@app.route("/consultas_pacientes/<int:id>")
@login_required
def consultas_paciente(id):
    paciente = db.session.get(Paciente, id)
    return render_template("consultas_pacientes.html", paciente=paciente, consultas=paciente.consultas if paciente else [])


@app.route("/enviar_whatsapp/<int:id>")
@login_required
def enviar_whatsapp(id):
    consulta = db.session.get(Consulta, id)
    if not consulta:
        return redirect(url_for("consultas_lista"))
    mensagem = f"Olá {consulta.paciente.nome}! Sua consulta está agendada para {consulta.data} às {consulta.horario}. Por favor, confirme sua presença."
    return redirect(f"https://wa.me/{consulta.paciente.telefone.replace('+', '')}?text={quote(mensagem)}")


@app.route("/confirmar_consulta/<int:id>")
@login_required
def confirmar_consulta(id):
    consulta = db.session.get(Consulta, id)
    if consulta:
        consulta.status = "Confirmada"
        db.session.commit()
        flash("Consulta confirmada! +15 XP", "success")
    return redirect(url_for("consultas_lista"))


@app.route("/realizar_consulta/<int:id>")
@login_required
def realizar_consulta(id):
    consulta = db.session.get(Consulta, id)
    if consulta and consulta.status != "Cancelada":
        consulta.status = "Realizada"
        db.session.commit()
        flash("Consulta marcada como realizada!", "success")
    return redirect(url_for("consultas_lista"))


@app.route("/cancelar_consulta/<int:id>")
@login_required
def cancelar_consulta(id):
    consulta = db.session.get(Consulta, id)
    if consulta:
        consulta.status = "Cancelada"
        db.session.commit()
        flash("Consulta cancelada.", "info")
    return redirect(url_for("consultas_lista"))


@app.route("/conquistas")
@login_required
def conquistas():
    pacientes = Paciente.query.count()
    consultas = Consulta.query.count()
    confirmadas = Consulta.query.filter(Consulta.status.in_(["Confirmada", "Realizada"])).count()
    xp = pacientes * 10 + consultas * 5 + confirmadas * 15
    nivel = min(10, xp // 50 + 1)
    proximo = nivel * 50
    badges = [
        ("Primeiro passo", "Cadastre seu primeiro paciente", pacientes >= 1, "✦"),
        ("Agenda organizada", "Agende 3 consultas", consultas >= 3, "◈"),
        ("Cuidado confirmado", "Confirme ou realize 3 consultas", confirmadas >= 3, "✓"),
        ("Ritmo constante", "Alcance 100 pontos de XP", xp >= 100, "★"),
    ]
    return render_template("conquistas.html", xp=xp, nivel=nivel, proximo=proximo, badges=badges,
                           pacientes=pacientes, consultas=consultas, confirmadas=confirmadas)


with app.app_context():
    db.create_all()


if __name__ == "__main__":
    app.run(debug=True)
